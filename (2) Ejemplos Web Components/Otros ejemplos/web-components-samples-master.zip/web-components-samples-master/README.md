# Web Components Examples

These are the examples of use of Web Components standard, used to write the Web Components tutorial at DesarrolloWeb.com

You will find some folders (01 to 04) with examples divided by specification. In the other folders find some advanced components, always in VanillaJS

[Manual de Web Components](http://www.desarrolloweb.com/manuales/web-components.html)
